from django.apps import AppConfig


class TmConfig(AppConfig):
    name = 'tm'
